package ParteFicheros;

public class Entrada {
    public static void main(String[] args) {
        OperacionFicheros operacionFicheros = new OperacionFicheros();
        //operacionFicheros.leerFichero("src/ParteFicheros/sources/ejercicio1.txt");
        operacionFicheros.leerFichero("src/ParteFicheros/sources/ejercicio2_3/ejercicio2.txt");
    }
}
