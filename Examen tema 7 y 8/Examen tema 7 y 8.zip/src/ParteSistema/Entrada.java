package ParteSistema;

import java.util.Scanner;

public class Entrada {
    public static void main(String[] args) {
        Inventario inventario = new Inventario<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduzca el nombre del producto");


    }
}
