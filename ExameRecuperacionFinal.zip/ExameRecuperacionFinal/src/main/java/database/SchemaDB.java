package database;

public interface SchemaDB {
    String DB_NAME = "productos_ces";
    String TAB_USER = "productos";
    String COL_ID = "id";
    String COL_NAME = "nombre";
    String COL_PRECIO = "precio";
    String COL_CANTIDAD = "cantidad";
}
