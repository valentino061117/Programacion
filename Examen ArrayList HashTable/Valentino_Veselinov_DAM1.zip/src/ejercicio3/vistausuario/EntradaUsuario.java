package ejercicio3.vistausuario;

import ejercicio3.controllerusuario.Usuario;

import java.util.Scanner;

public class EntradaUsuario {
    Usuario usuario = new Usuario();
    Scanner scanner = new Scanner(System.in);

    int opciones;

}
