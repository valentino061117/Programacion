package ejercicio1.controllerproducto;

import java.util.ArrayList;

public class Producto {
    private class producto{
        String nombreProducto;
        int precioProdcuto;

        public producto(String nombreProducto, int precioProdcuto){
            this.nombreProducto = nombreProducto;
            this.precioProdcuto = precioProdcuto;
        }
    }

    public static void Producto(){
        new ArrayList<producto>();
    }

}
