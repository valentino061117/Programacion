package ejercicio1.vistaproducto;

import ejercicio1.controllerproducto.Producto;

import java.util.Scanner;

public class EntradaProducto {
    Producto producto = new Producto();
    Scanner scanner = new Scanner(System.in);




}
