package ejercicio2.vistaclase;

import ejercicio2.controllerclase.Clase;

import java.util.Scanner;

public class EntradaClase {
    Clase clase = new Clase();
    Scanner scanner = new Scanner(System.in);

    int opciones;
    public static void menu(){
        do {
        System.out.println("Cuantos alumnos hay en clase?");
        System.out.println("Introduzca el numero de alumnos");
        System.out.println("Esta seguro de ser esos los alumnos? SI o NO");

        System.out.println("Bienvenido al menu, que quiere hacer?");
        System.out.println("Ver suspensos");
        System.out.println("Ver calificaciones");
        }while ()


    }
}
