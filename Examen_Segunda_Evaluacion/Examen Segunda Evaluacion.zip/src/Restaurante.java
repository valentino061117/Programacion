import java.util.ArrayList;

public class Restaurante {
    Restaurante restaurante = new Restaurante();
    private ArrayList<Clientes>listaClientes;
    private ArrayList<Consumiciones>listaConsumiciones;

    public Restaurante(Restaurante restaurante, ArrayList<Clientes> listaClientes, ArrayList<Consumiciones> listaConsumiciones) {
        this.restaurante = restaurante;
        this.listaClientes = listaClientes;
        this.listaConsumiciones = listaConsumiciones;
    }

    public Restaurante() {
        new ArrayList<Clientes>();
        new ArrayList<Consumiciones>();
    }

    public void agregarCliente(){
        for (Clientes clientes : listaClientes){
            if (agregarCliente(); )
        }
    }

    public void buscarCliente(int dni){
        for (Clientes clientes : listaClientes){

        }
    }

    public void admitirClientes(){

    }

    public void listaConsumiciones(){

    }

    public void totalPagar(){

    }

    public void totalCaja(){

    }

    public Restaurante getRestaurante() {
        return restaurante;
    }

    public void setRestaurante(Restaurante restaurante) {
        this.restaurante = restaurante;
    }

    public ArrayList<Clientes> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(ArrayList<Clientes> listaClientes) {
        this.listaClientes = listaClientes;
    }

    public ArrayList<Consumiciones> getListaConsumiciones() {
        return listaConsumiciones;
    }

    public void setListaConsumiciones(ArrayList<Consumiciones> listaConsumiciones) {
        this.listaConsumiciones = listaConsumiciones;
    }
}
