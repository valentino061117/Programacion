public class Entrada {
    public static void main(String[] args) {
    Comida comida = new Comida();
    Bebida bebida = new Bebida();
    Racion racion = new Racion();
    Restaurante restaurante = new Restaurante();

    }
}
