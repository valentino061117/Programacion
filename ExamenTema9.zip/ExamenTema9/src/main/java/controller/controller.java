package controller;

import model.Profesor;

import java.util.ArrayList;

public class controller {
    Profesor profesor = new Profesor();
    ArrayList<Profesor> lista;

}
