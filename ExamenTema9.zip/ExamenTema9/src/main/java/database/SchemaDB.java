package database;

public interface SchemaDB {
    String DB_Name = "profesores";
    String TAB_Name = "profesores";
    String COL_Dni = "dni";
    String COL_Nombre = "nombre";
    String COL_Salario = "salario";
}
